"""
Sieve Lens PDF report extension.

Generates a printable PDF report from a directory of documents.
Reuses the observation results from the dashboard extension.

Features:
  - Executive summary (total / clean / flagged / unparsed)
  - Hypothesis activation table
  - Mask distribution (chart if kaleido is available)
  - Detailed file list with H1–H7 badges
  - Deterministic output (fixed PDF metadata, sorted files)

Requires:
  - weasyprint >= 60.0
  - (optional) kaleido >= 0.2 and Plotly >= 5.0 for chart embedding

System dependencies (weasyprint):
  - macOS: brew install pango (Homebrew required)
  - Ubuntu/Debian: apt-get install libpango-1.0-0 libpangoft2-1.0-0
  - Fedora: dnf install pango

Install with:
    pip install sieve-lens[pdf-report]

Usage:
    from sieve_lens_ext.pdf_report import build_pdf_report

    build_pdf_report(
        input_dir="submissions/",
        output_path="report.pdf",
        include_charts=True,
    )
"""

from __future__ import annotations

import html
import re
import tempfile
from pathlib import Path
from typing import List, Optional, Sequence

try:
    from weasyprint import HTML
    WEASYPRINT_AVAILABLE = True
except (ImportError, OSError):
    WEASYPRINT_AVAILABLE = False

try:
    import plotly.graph_objects as go
    import plotly.io as pio
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False

try:
    import kaleido  # noqa: F401
    KALEIDO_AVAILABLE = True
except ImportError:
    KALEIDO_AVAILABLE = False

from sieve_lens import Observation, __version__
from sieve_lens_ext.i18n import get_translations, resolve_language, hypothesis_label as _hyp_label
from sieve_lens_ext.dashboard import (
    _HYPOTHESES,
    _HYPOTHESIS_LABELS,
    _DEFAULT_EXTENSIONS,
    scan_directory,
    analyze_batch,
    build_summary,
    DashboardSummary,
)


# ----------------------------------------------------------------------
# Chart rendering (optional, requires kaleido)
# ----------------------------------------------------------------------

def _render_mask_chart_png(summary: DashboardSummary, path: Path) -> bool:
    """Render the mask distribution chart as PNG. Return True on success."""
    if not (PLOTLY_AVAILABLE and KALEIDO_AVAILABLE):
        return False
    masks = list(summary.mask_counts.keys())
    counts = [summary.mask_counts[m] for m in masks]
    colors = []
    for m in masks:
        if m.startswith("0"):
            colors.append("#b0b0b0")
        elif m == "1000-000":
            colors.append("#22863a")
        else:
            colors.append("#d73a49")

    fig = go.Figure(
        data=[go.Bar(
            x=masks, y=counts,
            marker_color=colors,
            text=counts, textposition="auto",
        )]
    )
    fig.update_layout(
        title="Mask Distribution",
        xaxis_title="Mask",
        yaxis_title="Files",
        margin=dict(l=50, r=20, t=50, b=80),
        width=700, height=380,
        font=dict(size=11),
    )
    try:
        fig.write_image(str(path), format="png", scale=2)
        return True
    except Exception:
        return False


def _render_hypothesis_chart_png(summary: DashboardSummary, path: Path) -> bool:
    if not (PLOTLY_AVAILABLE and KALEIDO_AVAILABLE):
        return False
    labels = [_HYPOTHESIS_LABELS[h] for h in _HYPOTHESES]
    values = [summary.hypothesis_counts.get(h, 0) for h in _HYPOTHESES]
    colors = ["#0366d6" if h == "H1" else "#d73a49" for h in _HYPOTHESES]

    fig = go.Figure(
        data=[go.Bar(
            x=labels, y=values,
            marker_color=colors,
            text=values, textposition="auto",
        )]
    )
    fig.update_layout(
        title="Hypothesis Activation",
        xaxis_title="Hypothesis",
        yaxis_title="Files with H = 1",
        margin=dict(l=50, r=20, t=50, b=100),
        width=700, height=380,
        font=dict(size=11),
    )
    try:
        fig.write_image(str(path), format="png", scale=2)
        return True
    except Exception:
        return False


# ----------------------------------------------------------------------
# HTML template for PDF
# ----------------------------------------------------------------------

_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<!-- v0.11.0 fix (#16): fixed timestamps make the PDF byte-deterministic.
     WeasyPrint adopts these as the PDF creation/modification dates. -->
<meta name="dcterms.created" content="2000-01-01T00:00:00Z">
<meta name="dcterms.modified" content="2000-01-01T00:00:00Z">
<title>{{ t.report_title }}</title>
<style>
@page {
  size: A4 portrait;
  margin: 18mm 14mm 16mm 14mm;
  @bottom-center {
    content: "Sieve Lens Observation Report — page " counter(page) " / " counter(pages);
    font-size: 8pt;
    color: #888;
  }
}
body {
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 10pt;
  color: #1a1a1a;
  line-height: 1.4;
}
h1 { font-size: 18pt; margin: 0 0 4mm 0; }
h2 { font-size: 12pt; margin: 6mm 0 2mm 0; border-bottom: 1px solid #ccc; padding-bottom: 1mm; }
h3 { font-size: 10pt; margin: 4mm 0 2mm 0; }

.header-meta {
  font-size: 9pt;
  color: #555;
  margin-bottom: 4mm;
}
.header-meta code { background: #f5f5f5; padding: 0 2px; }

.statement {
  font-style: italic;
  color: #444;
  border-left: 3px solid #0366d6;
  padding-left: 4mm;
  margin: 4mm 0;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin: 2mm 0;
  font-size: 9pt;
}
th, td {
  text-align: left;
  padding: 1.5mm 2mm;
  border-bottom: 0.5pt solid #ddd;
}
th {
  background: #f0f0f0;
  font-weight: 600;
}
tr.flagged { background: #fff5f5; }
tr.unparsed { background: #f5f5f5; color: #888; }

.summary-grid {
  display: table;
  width: 100%;
  margin: 3mm 0;
  border-collapse: separate;
  border-spacing: 3mm 0;
}
.summary-card {
  display: table-cell;
  width: 25%;
  border: 0.5pt solid #ddd;
  border-radius: 2mm;
  padding: 3mm;
  background: #fafafa;
}
.summary-label { font-size: 8pt; color: #777; }
.summary-value { font-size: 16pt; font-weight: 600; margin-top: 1mm; }
.summary-card.warn .summary-value { color: #d73a49; }
.summary-card.ok   .summary-value { color: #22863a; }

.mask {
  font-family: "SF Mono", Menlo, Consolas, monospace;
  font-weight: 600;
}
.mask-flag { color: #d73a49; }
.mask-clean { color: #22863a; }
.mask-unparsed { color: #888; }

.badge {
  display: inline-block;
  padding: 0.5mm 1.2mm;
  margin: 0 0.5mm;
  border-radius: 1mm;
  font-size: 7pt;
  font-family: "SF Mono", Menlo, Consolas, monospace;
}
.badge.on { background: #d73a49; color: white; }
.badge.off { background: #eee; color: #999; }

.file-list td.file { font-family: "SF Mono", Menlo, Consolas, monospace; font-size: 8pt; }
.file-list td.evidence { font-size: 8pt; color: #555; }

.chart-img { max-width: 100%; margin: 2mm 0; }

footer-note {
  display: block;
  margin-top: 8mm;
  padding-top: 3mm;
  border-top: 1px solid #ccc;
  font-size: 8pt;
  color: #666;
}
</style>
</head>
<body>

<h1>{{ t.report_title }}</h1>

<div class="header-meta">
  {{ t.report_source }}: <code>{{ input_dir }}</code><br>
  {{ t.report_files_scanned }}: {{ summary.total_files }} &mdash;
  {{ t.report_parsed }}: {{ summary.parsed_files }} &mdash;
  {{ t.report_clean }}: {{ summary.clean_files }} &mdash;
  {{ t.report_flagged }}: {{ summary.flagged_files }} &mdash;
  {{ t.report_unparsed }}: {{ summary.unparsed_files }}
</div>

<p class="statement">
  {{ t.footer_statement_report }}
  {{ t.footer_human_review }}
</p>

<h2>{{ t.section_summary }}</h2>

<div class="summary-grid">
  <div class="summary-card">
    <div class="summary-label">{{ t.summary_total }}</div>
    <div class="summary-value">{{ summary.total_files }}</div>
  </div>
  <div class="summary-card ok">
    <div class="summary-label">{{ t.summary_clean }}</div>
    <div class="summary-value">{{ summary.clean_files }}</div>
  </div>
  <div class="summary-card warn">
    <div class="summary-label">{{ t.summary_flagged }}</div>
    <div class="summary-value">{{ summary.flagged_files }}</div>
  </div>
  <div class="summary-card">
    <div class="summary-label">{{ t.summary_unparsed }}</div>
    <div class="summary-value">{{ summary.unparsed_files }}</div>
  </div>
</div>

{% if chart_mask_path or chart_hypothesis_path %}
<h2>{{ t.section_charts }}</h2>
{% if chart_mask_path %}
<img class="chart-img" src="{{ chart_mask_path }}" alt="Mask Distribution">
{% endif %}
{% if chart_hypothesis_path %}
<img class="chart-img" src="{{ chart_hypothesis_path }}" alt="Hypothesis Activation">
{% endif %}
{% endif %}

<h2>{{ t.section_hypothesis }}</h2>
<table>
<thead>
<tr><th>{{ t.table_bit }}</th><th>{{ t.table_name }}</th><th>{{ t.table_h_count }}</th></tr>
</thead>
<tbody>
{% for h in hypothesis_keys %}
<tr>
  <td><code>{{ h }}</code></td>
  <td>{{ hypothesis_labels[h] }}</td>
  <td>{{ summary.hypothesis_counts[h] }}</td>
</tr>
{% endfor %}
</tbody>
</table>

<h2>{{ t.section_mask }}</h2>
<table>
<thead>
<tr><th>{{ t.table_mask_long }}</th><th>{{ t.summary_total }}</th></tr>
</thead>
<tbody>
{% for mask, count in summary.mask_counts.items() %}
<tr>
  <td class="mask">{{ mask }}</td>
  <td>{{ count }}</td>
</tr>
{% endfor %}
</tbody>
</table>

<h2>{{ t.section_files }}</h2>
<table class="file-list">
<thead>
<tr>
  <th>{{ t.table_file }}</th>
  <th>{{ t.table_mask }}</th>
  <th>H1 &ndash; H7</th>
  <th>{{ t.table_evidence_first }}</th>
</tr>
</thead>
<tbody>
{% for obs in observations %}
<tr class="{% if obs.row_class %}{{ obs.row_class }}{% endif %}">
  <td class="file">{{ obs.display_path }}</td>
  <td class="mask {{ obs.mask_class }}">{{ obs.mask }}</td>
  <td>
    {% for h in hypothesis_keys %}
      <span class="badge {{ 'on' if obs.h_states[h] else 'off' }}">{{ h }}</span>
    {% endfor %}
  </td>
  <td class="evidence">{{ obs.evidence_summary }}</td>
</tr>
{% endfor %}
</tbody>
</table>

<footer-note>
  Generated deterministically by Sieve Lens v{{ version }}.
  No timestamps, randomness, or external resources are included.<br>
  This is an observation engine, not a judgment engine.
</footer-note>

</body>
</html>
"""


# ----------------------------------------------------------------------
# Row data (mirrors dashboard's _row_data but returns plain dict)
# ----------------------------------------------------------------------

def _row_data(obs: Observation, base_dir: Optional[Path]) -> dict:
    h1 = obs.h_states.get("H1", 0)
    if h1 == 0:
        row_class = "unparsed"
        mask_class = "mask-unparsed"
    elif any(obs.h_states.get(h, 0) == 1 for h in _HYPOTHESES[1:]):
        row_class = "flagged"
        mask_class = "mask-flag"
    else:
        row_class = ""
        mask_class = "mask-clean"

    display_path = obs.source
    if base_dir:
        try:
            display_path = str(Path(obs.source).relative_to(base_dir))
        except ValueError:
            display_path = Path(obs.source).name

    evidence_parts = []
    for h in _HYPOTHESES:
        if h == "H1":
            continue
        items = obs.evidence.get(h, [])
        for item in items:
            if item and item != "none":
                evidence_parts.append(f"[{h}] {item}")
                break
    evidence_summary = " / ".join(evidence_parts[:1]) if evidence_parts else ""
    if len(evidence_summary) > 100:
        evidence_summary = evidence_summary[:97] + "..."

    return {
        "source": obs.source,
        "display_path": display_path,
        "mask": obs.mask,
        "h_states": obs.h_states,
        "row_class": row_class,
        "mask_class": mask_class,
        "evidence_summary": evidence_summary,
    }


# ----------------------------------------------------------------------
# Rendering
# ----------------------------------------------------------------------

def render_pdf_report_html(
    summary: DashboardSummary,
    observations: List[Observation],
    input_dir: str,
    base_dir: Optional[Path] = None,
    chart_mask_path: Optional[Path] = None,
    chart_hypothesis_path: Optional[Path] = None,
    version: Optional[str] = None,
    lang: str = "en",
) -> str:
    from jinja2 import Template

    version = version or __version__
    rows = [_row_data(obs, base_dir) for obs in observations]
    t = get_translations(lang)
    template = Template(_TEMPLATE, autoescape=True)
    return template.render(
        t=t,
        input_dir=input_dir,
        summary=summary,
        observations=rows,
        hypothesis_keys=_HYPOTHESES,
        hypothesis_labels={h: _hyp_label(lang, h) for h in _HYPOTHESES},
        chart_mask_path=str(chart_mask_path) if chart_mask_path else "",
        chart_hypothesis_path=str(chart_hypothesis_path) if chart_hypothesis_path else "",
        version=version,
    )


# ----------------------------------------------------------------------
# Public entry point
# ----------------------------------------------------------------------

_XMP_FIXED = b"xmp.did:00000000-0000-0000-0000-000000000000"


def _pdf_pin_xmp(data):
    """Replace volatile xmp.did UUIDs (weasyprint metadata.py: uuid4)
    with a fixed value. Return new bytes, or None if unchanged."""
    if not isinstance(data, bytes) or b"xmp.did:" not in data:
        return None
    out = bytearray(data)
    pos = 0
    while True:
        start = out.find(b"xmp.did:", pos)
        if start == -1:
            break
        end = out.find(b"<", start)
        if end == -1:
            end = len(out)
        out[start:end] = _XMP_FIXED
        pos = start + len(_XMP_FIXED)
    return bytes(out)


_XMP_FIXED_STR = "xmp.did:00000000-0000-0000-0000-000000000000"


def _pdf_pin_xmp_str(data):
    """Str variant: the XMP packet may be serialized as str."""
    if not isinstance(data, str) or "xmp.did:" not in data:
        return None
    return re.sub(r"xmp\.did:[^<]*", _XMP_FIXED_STR, data)


def _pdf_determinize_objects(objects):
    """Pin volatile fields across a pydyf object graph.

    pydyf ground truth (read from pydyf/__init__.py): pdf.objects is a
    list of Object instances - NOT dicts/lists. A Stream payload lives in
    obj.stream (a list of bytes/str chunks) and object metadata in
    obj.extra (a Dictionary, i.e. a dict subclass). A walk that only
    recurses dicts/lists silently skips every Object and never reaches
    the font or XMP bytes. Descend explicitly:

      objects (list) -> Object -> .stream (list) -> bytes/str chunks
                                 -> .extra  (dict) -> values
    """
    def rewrite(data):
        if isinstance(data, bytes):
            result = data
            changed = False
            fixed = _pdf_determinize_font(result)
            if fixed is not None:
                result = fixed
                changed = True
            fixed = _pdf_pin_xmp(result)
            if fixed is not None:
                result = fixed
                changed = True
            return result if changed else None
        if isinstance(data, str):
            return _pdf_pin_xmp_str(data)
        return None

    def walk(container):
        if isinstance(container, dict):
            for key in list(container.keys()):
                new = rewrite(container[key])
                if new is not None:
                    container[key] = new
                else:
                    walk(container[key])
        elif isinstance(container, (list, tuple)):
            for i in range(len(container)):
                new = rewrite(container[i])
                if new is not None:
                    container[i] = new
                else:
                    walk(container[i])
        else:
            stream = getattr(container, "stream", None)
            if isinstance(stream, list):
                walk(stream)
            extra = getattr(container, "extra", None)
            if extra is not None and extra is not stream:
                walk(extra)

    walk(objects)


def _pdf_determinize_font(data):
    """Zero volatile fields of an embedded sfnt (TrueType/OpenType) font:
    head.checkSumAdjustment and head.created / head.modified. fontTools
    rewrites head.modified with the current time on save (recalcTimestamp),
    and the head directory checksum follows from it - CI-verified (differing
    byte inside the head table directory entry) as the last nondeterminism
    source of the PDF report. Return new bytes, or None if not a font."""
    if not isinstance(data, bytes) or len(data) < 16:
        return None
    if data[:4] not in (b"\x00\x01\x00\x00", b"OTTO", b"true"):
        return None
    out = bytearray(data)
    num_tables = int.from_bytes(out[4:6], "big")
    if num_tables == 0 or 12 + num_tables * 16 > len(out):
        return None
    for i in range(num_tables):
        rec = 12 + i * 16
        if bytes(out[rec:rec + 4]) != b"head":
            continue
        off = int.from_bytes(out[rec + 8:rec + 12], "big")
        length = int.from_bytes(out[rec + 12:rec + 16], "big")
        if length < 36 or off + length > len(out):
            return None
        out[off + 8:off + 12] = b"\x00" * 4      # checkSumAdjustment
        # head layout: 20-28 created, 28-36 modified (longDateTime).
        # fontTools (recalcTimestamp) rewrites modified with now(); the
        # CI byte-diff showed the recomputed head checksum differing by
        # exactly the 1-second timestamp delta. Zero BOTH fields, and
        # keep flags/unitsPerEm (16-20) intact.
        out[off + 20:off + 36] = b"\x00" * 16    # created + modified
        table = bytes(out[off:off + length])
        padded = table + b"\x00" * (-len(table) % 4)
        checksum = 0
        for k in range(0, len(padded), 4):
            checksum = (checksum + int.from_bytes(padded[k:k + 4], "big")) & 0xFFFFFFFF
        out[rec + 4:rec + 8] = checksum.to_bytes(4, "big")
        return bytes(out)
    return None


def build_pdf_report(
    input_dir: Path,
    output_path: Path,
    recursive: bool = True,
    extensions: Optional[Sequence[str]] = None,
    include_charts: bool = True,
    max_workers: Optional[int] = None,
    lang: str = "auto",
) -> Path:
    """Generate a PDF report from a directory of documents.

    Args:
        input_dir: Directory containing documents.
        output_path: Path for the generated PDF file.
        recursive: If True, scan subdirectories.
        extensions: Override the default file extension filter.
        include_charts: If True and kaleido is available, embed PNG charts.
        max_workers: Number of parallel workers.

    Returns:
        The output path.
    """
    if not WEASYPRINT_AVAILABLE:
        raise ImportError(
            "sieve_lens_ext.pdf_report requires weasyprint. "
            "Install with: pip install sieve-lens[pdf-report]"
        )

    input_dir = Path(input_dir).resolve()
    output_path = Path(output_path)

    exts = tuple(extensions) if extensions else _DEFAULT_EXTENSIONS
    files = scan_directory(input_dir, extensions=exts, recursive=recursive)
    observations = analyze_batch(files, max_workers=max_workers)
    summary = build_summary(observations)

    # Render charts to PNG in a temporary directory
    chart_mask_path: Optional[Path] = None
    chart_hypothesis_path: Optional[Path] = None

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        if include_charts:
            p1 = tmp / "mask.png"
            if _render_mask_chart_png(summary, p1):
                chart_mask_path = p1
            p2 = tmp / "hypothesis.png"
            if _render_hypothesis_chart_png(summary, p2):
                chart_hypothesis_path = p2

        resolved_lang = lang
        if lang == "auto":
            sample_texts = []
            for obs in observations[:5]:
                sample_texts.append(obs.source)
                for seg in obs.segments[:5]:
                    sample_texts.append(seg.text)
            resolved_lang = resolve_language(lang, sample_texts)

        html_text = render_pdf_report_html(
            summary=summary,
            observations=observations,
            input_dir=str(input_dir),
            base_dir=input_dir,
            chart_mask_path=chart_mask_path,
            chart_hypothesis_path=chart_hypothesis_path,
            lang=resolved_lang,
        )

        output_path.parent.mkdir(parents=True, exist_ok=True)

        # WeasyPrint: build PDF. Fixed metadata for determinism.
        doc = HTML(string=html_text, base_url=str(input_dir))
        # Byte determinism (all three non-determinism sources addressed):
        #   1. dates   -> pinned by dcterms.created/modified meta tags;
        #   2. /ID     -> not written (pydyf identifier defaults to False);
        #   3. xmp.did -> uuid4() in the XMP DocumentID is rewritten to a
        #      fixed value by this finisher (weasyprint metadata.py:129).
        def _determinize(document_arg, pdf_arg):
            # Descend the REAL pydyf structure (see _pdf_determinize_objects):
            # Object instances expose .stream (list) / .extra (dict); plain
            # dict/list recursion never reaches the font or XMP payloads.
            _pdf_determinize_objects(pdf_arg.objects)

        doc.write_pdf(
            target=str(output_path),
            presentational_hints=False,
            optimize_images=True,
            # CI-verified: zlib stream compression of embedded fonts is
            # not byte-stable across runs (Length 3930 vs 3931 in the
            # same font). Disabling stream compression removes the last
            # nondeterminism source; the xmp.did pin stays via finisher.
            uncompressed_pdf=True,
            finisher=_determinize,
        )

    return output_path


__all__ = [
    "build_pdf_report",
    "render_pdf_report_html",
]